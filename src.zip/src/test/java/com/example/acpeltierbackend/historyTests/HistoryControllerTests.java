package com.example.acpeltierbackend.historyTests;

import com.example.acpeltierbackend.service.HistoryService;
import com.example.acpeltierbackend.web.controller.HistoryController;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class HistoryControllerTests {

    @Mock
    private HistoryService history;

    static class Row {
        public LocalDate statusDay;
        public Double minAmbientTempC;
        public Double maxAmbientTempC;

        Row(LocalDate day, Double min, Double max) {
            this.statusDay = day;
            this.minAmbientTempC = min;
            this.maxAmbientTempC = max;
        }
    }

    @Test
    void daily_returnsMappedData() {
        HistoryController controller = new HistoryController(history);

        var rows = List.of(
                new Row(LocalDate.of(2024, 1, 1), 10.0, 20.0),
                new Row(LocalDate.of(2024, 1, 2), 11.0, 21.0)
        );

        when(history.getLastDays(7)).thenReturn((List) rows);

        Map<String, Object> result = controller.daily(7);

        assertNotNull(result);
        assertTrue(result.containsKey("days"));

        var days = (List<Map<String, Object>>) result.get("days");

        assertEquals(2, days.size());
        assertEquals("2024-01-01", days.get(0).get("day"));
        assertEquals(10.0, days.get(0).get("minAmbientTempC"));
        assertEquals(20.0, days.get(0).get("maxAmbientTempC"));
    }

    @Test
    void daily_handlesNullDate() {
        HistoryController controller = new HistoryController(history);

        var rows = List.of(
                new Row(null, 5.0, 15.0)
        );

        when(history.getLastDays(7)).thenReturn((List) rows);

        Map<String, Object> result = controller.daily(7);

        var days = (List<Map<String, Object>>) result.get("days");

        assertNull(days.get(0).get("day"));
        assertEquals(5.0, days.get(0).get("minAmbientTempC"));
        assertEquals(15.0, days.get(0).get("maxAmbientTempC"));
    }
}