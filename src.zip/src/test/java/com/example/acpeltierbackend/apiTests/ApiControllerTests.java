package com.example.acpeltierbackend.apiTests;

import com.example.acpeltierbackend.security.DeviceRegistry;
import com.example.acpeltierbackend.web.controller.ApiController;
import com.example.acpeltierbackend.web.dto.Dtos;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.socket.WebSocketSession;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApiControllerTests {

    @Mock
    private DeviceRegistry reg;

    @Mock
    private WebSocketSession session;

    @Test
    void health_returnsOk() {
        when(reg.online()).thenReturn(true);

        ApiController controller = new ApiController(reg);

        var result = controller.health();

        assertEquals(true, result.get("ok"));
        assertEquals(true, result.get("deviceOnline"));
    }

    @Test
    void status_returnsLatestStatus() {
        Dtos.StatusResponse status = mock(Dtos.StatusResponse.class);
        when(reg.getLatestStatus()).thenReturn(status);

        ApiController controller = new ApiController(reg);

        assertSame(status, controller.status());
    }

    @Test
    void command_offline_returns409() throws Exception {
        when(reg.online()).thenReturn(false);

        ApiController controller = new ApiController(reg);

        Dtos.CommandRequest req = mock(Dtos.CommandRequest.class);

        var response = controller.command(req);

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }

    @Test
    void command_online_sendsMessage() throws Exception {
        when(reg.online()).thenReturn(true);
        when(reg.getSession()).thenReturn(session);

        ApiController controller = new ApiController(reg);

        Dtos.CommandRequest req = mock(Dtos.CommandRequest.class);

        var response = controller.command(req);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(session).sendMessage(any());
    }
}